
Upload plugin file to direct link (Cam and pwd)
Build your server and move it to an other folder (i advice to not test server launching from builder folder)
(server change his write permission, take care, security tab)
If builder can't delete old server, it return an error. Change permission and delete if you want build an other.
